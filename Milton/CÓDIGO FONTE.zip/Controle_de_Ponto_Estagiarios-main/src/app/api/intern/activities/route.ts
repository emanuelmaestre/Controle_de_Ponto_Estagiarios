import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { createSupabaseServerClient, createSupabaseServiceClient } from '@/lib/supabase/server'
export const dynamic = 'force-dynamic'

const PONTOS_POR_ATIVIDADE = 5

// ── Vocabulário correto de referência ────────────────────────────────────────
// Cada palavra aqui é a forma CERTA. O algoritmo fuzzy encontra a mais próxima.
const VOCABULARIO: string[] = [

  // ── LIMPEZA / HIGIENE ────────────────────────────────────────────────────────
  'LIMPEZA', 'LIMPEZAS', 'LIMPAR', 'LIMPANDO', 'LIMPEI', 'LIMPO',
  'VARREDURA', 'VARRER', 'VARRENDO', 'VARRI',
  'VASSOURA', 'VASSOURAS',
  'HIGIENIZAÇÃO', 'HIGIENIZAR', 'HIGIENIZANDO', 'HIGIENIZEI',
  'DESINFECÇÃO', 'DESINFETAR', 'DESINFETANDO', 'DESINFETEI',
  'ESTERILIZAÇÃO', 'ESTERILIZAR', 'ESTERILIZANDO',
  'LAVAGEM', 'LAVAR', 'LAVANDO', 'LAVEI',
  'FAXINA', 'FAXINANDO',
  'DESCARTE', 'DESCARTANDO', 'DESCARTAR', 'DESCARTEI',
  'RESÍDUO', 'RESÍDUOS', 'LIXO',

  // ── ORGANIZAÇÃO / ARRUMAÇÃO ──────────────────────────────────────────────────
  'ORGANIZAÇÃO', 'ORGANIZAR', 'ORGANIZANDO', 'ORGANIZEI',
  'ARRUMAÇÃO', 'ARRUMAR', 'ARRUMANDO', 'ARRUMEI',
  'ORDENAÇÃO', 'ORDENAR', 'ORDENANDO', 'ORDENEI',
  'SEPARAÇÃO', 'SEPARAR', 'SEPARANDO', 'SEPAREI',
  'SELEÇÃO', 'SELECIONAR', 'SELECIONANDO', 'SELECIONEI',
  'MONTAGEM', 'MONTAR', 'MONTANDO', 'MONTEI',
  'DESMONTAGEM', 'DESMONTAR', 'DESMONTANDO', 'DESMONTEI',
  'EMPILHAMENTO', 'EMPILHAR', 'EMPILHANDO',
  'ARMAZENAMENTO', 'ARMAZENAR', 'ARMAZENANDO', 'ARMAZENEI',
  'DISPOSIÇÃO', 'DISPOR',

  // ── RECEPÇÃO / ATENDIMENTO ───────────────────────────────────────────────────
  'RECEPÇÃO', 'RECEPCIONAR', 'RECEPCIONANDO', 'RECEPCIONEI',
  'ATENDIMENTO', 'ATENDER', 'ATENDENDO', 'ATENDI',
  'ACOLHIMENTO', 'ACOLHER', 'ACOLHENDO',
  'TRIAGEM', 'TRIAR', 'TRIANDO',
  'ORIENTAÇÃO', 'ORIENTAR', 'ORIENTANDO', 'ORIENTEI',
  'ENCAMINHAMENTO', 'ENCAMINHAR', 'ENCAMINHANDO', 'ENCAMINHEI',
  'SUPORTE', 'APOIO',

  // ── DOCUMENTOS / ADMINISTRATIVO ─────────────────────────────────────────────
  'DOCUMENTO', 'DOCUMENTOS', 'DOCUMENTAÇÃO', 'DOCUMENTAR', 'DOCUMENTANDO',
  'ARQUIVAMENTO', 'ARQUIVAR', 'ARQUIVANDO', 'ARQUIVEI',
  'ARQUIVO', 'ARQUIVOS',
  'DIGITAÇÃO', 'DIGITAR', 'DIGITANDO', 'DIGITEI',
  'IMPRESSÃO', 'IMPRIMIR', 'IMPRIMINDO', 'IMPRIMI',
  'CATALOGAÇÃO', 'CATALOGAR', 'CATALOGANDO', 'CATALOGUEI',
  'PROTOCOLO', 'PROTOCOLANDO', 'PROTOCOLAR', 'PROTOCOLEI',
  'PLANILHA', 'PLANILHAS', 'PLANILHAR',
  'RELATÓRIO', 'RELATÓRIOS',
  'FORMULÁRIO', 'FORMULÁRIOS',
  'FICHA', 'FICHAS',
  'CADASTRO', 'CADASTROS', 'CADASTRAR', 'CADASTRANDO', 'CADASTREI',
  'PREENCHIMENTO', 'PREENCHER', 'PREENCHENDO', 'PREENCHEI',
  'VERIFICAÇÃO', 'VERIFICAR', 'VERIFICANDO', 'VERIFIQUEI',
  'CONFERÊNCIA', 'CONFERIR', 'CONFERINDO', 'CONFERI',
  'CLASSIFICAÇÃO', 'CLASSIFICAR', 'CLASSIFICANDO', 'CLASSIFIQUEI',
  'RECEBIMENTO', 'RECEBER', 'RECEBENDO', 'RECEBI',
  'ENTREGA', 'ENTREGAR', 'ENTREGANDO', 'ENTREGEI', 'ENTREGUE',
  'ENVIO', 'ENVIAR', 'ENVIANDO', 'ENVIEI',
  'EMISSÃO', 'EMITIR', 'EMITINDO', 'EMITI',
  'CONTROLE', 'CONTROLAR', 'CONTROLANDO', 'CONTROLEI',
  'REGISTRO', 'REGISTROS', 'REGISTRAR', 'REGISTRANDO', 'REGISTREI',
  'ASSINATURA', 'ASSINAR', 'ASSINANDO', 'ASSINEI',
  'CÓPIA', 'CÓPIAS', 'COPIAR', 'COPIANDO', 'COPIEI',
  'XEROX', 'XEROCAR',
  'DIGITALIZAÇÃO', 'DIGITALIZAR', 'DIGITALIZANDO', 'DIGITALIZEI',
  'ESCANEAMENTO', 'ESCANEAR', 'ESCANEANDO', 'ESCANEEI',

  // ── REUNIÃO / TREINAMENTO / CAPACITAÇÃO ─────────────────────────────────────
  'REUNIÃO', 'REUNIÕES', 'REUNIR', 'REUNINDO', 'REUNI',
  'TREINAMENTO', 'TREINAMENTOS', 'TREINAR', 'TREINANDO', 'TREINEI',
  'CAPACITAÇÃO', 'CAPACITAR', 'CAPACITANDO', 'CAPACITEI',
  'CURSO', 'CURSOS',
  'PALESTRA', 'PALESTRAS',
  'APRESENTAÇÃO', 'APRESENTAR', 'APRESENTANDO', 'APRESENTEI',
  'WORKSHOP',
  'INSTRUÇÃO', 'INSTRUIR', 'INSTRUINDO',

  // ── MONITORAMENTO / SUPORTE / COLABORAÇÃO ───────────────────────────────────
  'MONITORAMENTO', 'MONITORAR', 'MONITORANDO', 'MONITOREI',
  'ACOMPANHAMENTO', 'ACOMPANHAR', 'ACOMPANHANDO', 'ACOMPANHEI',
  'SUPERVISÃO', 'SUPERVISIONAR', 'SUPERVISIONANDO',
  'COLABORAÇÃO', 'COLABORAR', 'COLABORANDO', 'COLABOREI',
  'AUXILIAR', 'AUXILIANDO', 'AUXILIEI',
  'AJUDAR', 'AJUDANDO', 'AJUDEI',
  'APOIAR', 'APOIANDO', 'APOIEI',

  // ── ESTOQUE / MATERIAIS / ALMOXARIFADO ──────────────────────────────────────
  'ESTOQUE', 'ESTOCAR', 'ESTOCANDO', 'ESTOQUEI',
  'MATERIAL', 'MATERIAIS',
  'SUPRIMENTO', 'SUPRIMENTOS',
  'INSUMO', 'INSUMOS',
  'INVENTÁRIO', 'INVENTARIAR', 'INVENTARIANDO',
  'REQUISIÇÃO', 'REQUISITAR', 'REQUISITANDO', 'REQUISITEI',
  'COMPRAS', 'COMPRAR', 'COMPRANDO', 'COMPREI',
  'REPOSIÇÃO', 'REPOR', 'REPONDO', 'REPUS',
  'ETIQUETAGEM', 'ETIQUETAR', 'ETIQUETANDO', 'ETIQUETEI',
  'ETIQUETA', 'ETIQUETAS',
  'CONTAGEM', 'CONTAR', 'CONTANDO', 'CONTEI',

  // ── TECNOLOGIA / INFORMÁTICA / SISTEMAS ─────────────────────────────────────
  'INFORMÁTICA',
  'COMPUTADOR', 'COMPUTADORES',
  'SISTEMA', 'SISTEMAS',
  'IMPRESSORA', 'IMPRESSORAS',
  'EQUIPAMENTO', 'EQUIPAMENTOS',
  'MANUTENÇÃO', 'MANUTENÇÕES', 'MANTER', 'MANTENDO', 'MANTIVE',
  'INSTALAÇÃO', 'INSTALAR', 'INSTALANDO', 'INSTALEI',
  'CONFIGURAÇÃO', 'CONFIGURAR', 'CONFIGURANDO', 'CONFIGUREI',
  'ATUALIZAÇÃO', 'ATUALIZAR', 'ATUALIZANDO', 'ATUALIZEI',
  'AGENDAMENTO', 'AGENDAR', 'AGENDANDO', 'AGENDEI',
  'ACESSO', 'ACESSAR', 'ACESSANDO', 'ACESSEI',
  'CADASTRAMENTO',
  'BACKUP', 'BACKUPS',
  'REDE', 'REDES',
  'SUPORTE',
  'HARDWARE', 'SOFTWARE',

  // ── LABORATÓRIO / CIÊNCIAS ───────────────────────────────────────────────────
  'LABORATÓRIO', 'LABORATÓRIOS',
  'ANÁLISE', 'ANÁLISES', 'ANALISAR', 'ANALISANDO', 'ANALISEI',
  'AMOSTRA', 'AMOSTRAS',
  'EXPERIMENTO', 'EXPERIMENTOS', 'EXPERIMENTAR', 'EXPERIMENTANDO',
  'PESQUISA', 'PESQUISAS', 'PESQUISAR', 'PESQUISANDO', 'PESQUISEI',
  'COLETA', 'COLETAR', 'COLETANDO', 'COLETEI',
  'MEDIÇÃO', 'MEDIR', 'MEDINDO', 'MEDI',
  'PESAGEM', 'PESAR', 'PESANDO', 'PESEI',
  'CALIBRAÇÃO', 'CALIBRAR', 'CALIBRANDO', 'CALIBREI',
  'PREPARAÇÃO', 'PREPARAR', 'PREPARANDO', 'PREPAREI',
  'PREPARO',
  'MISTURA', 'MISTURAR', 'MISTURANDO', 'MISTUREI',
  'SOLUÇÃO', 'SOLUÇÕES',
  'REAGENTE', 'REAGENTES',
  'VIDRARIA', 'VIDRARIAS',
  'MICROSCÓPIO', 'CENTRÍFUGA', 'AUTOCLAVE',
  'RESULTADO', 'RESULTADOS',
  'LAUDO', 'LAUDOS',
  'EXAME', 'EXAMES',
  'INSPEÇÃO', 'INSPECIONAR', 'INSPECIONANDO', 'INSPECIONEI',
  'VISTORIA', 'VISTORIAR', 'VISTORIANDO', 'VISTORIEI',

  // ── AÇÕES GERAIS / VERBOS COMUNS ────────────────────────────────────────────
  'REALIZAR', 'REALIZANDO', 'REALIZEI', 'REALIZAÇÃO',
  'EXECUTAR', 'EXECUTANDO', 'EXECUTEI', 'EXECUÇÃO',
  'DESENVOLVER', 'DESENVOLVENDO', 'DESENVOLVI', 'DESENVOLVIMENTO',
  'ELABORAR', 'ELABORANDO', 'ELABOREI', 'ELABORAÇÃO',
  'FINALIZAR', 'FINALIZANDO', 'FINALIZEI', 'FINALIZAÇÃO',
  'CONCLUIR', 'CONCLUINDO', 'CONCLUÍ', 'CONCLUSÃO',
  'INICIAR', 'INICIANDO', 'INICIEI', 'INÍCIO',
  'COMEÇAR', 'COMEÇANDO', 'COMECEI',
  'PARTICIPAR', 'PARTICIPANDO', 'PARTICIPEI', 'PARTICIPAÇÃO',
  'EFETUAR', 'EFETUANDO', 'EFETUEI',
  'REVISAR', 'REVISANDO', 'REVISEI', 'REVISÃO',
  'CORRIGIR', 'CORRIGINDO', 'CORRIGI', 'CORREÇÃO',
  'AJUSTAR', 'AJUSTANDO', 'AJUSTEI', 'AJUSTE', 'AJUSTES',
  'TESTAR', 'TESTANDO', 'TESTEI', 'TESTE', 'TESTES',
  'VALIDAR', 'VALIDANDO', 'VALIDEI', 'VALIDAÇÃO',
  'APROVAR', 'APROVANDO', 'APROVEI', 'APROVAÇÃO',
  'LEVANTAR', 'LEVANTANDO', 'LEVANTEI', 'LEVANTAMENTO',
  'MAPEAR', 'MAPEANDO', 'MAPEEI', 'MAPEAMENTO',
  'IDENTIFICAR', 'IDENTIFICANDO', 'IDENTIFIQUEI',
  'SOLICITAR', 'SOLICITANDO', 'SOLICITEI', 'SOLICITAÇÃO',
  'COMUNICAR', 'COMUNICANDO', 'COMUNIQUEI', 'COMUNICAÇÃO',
  'INFORMAR', 'INFORMANDO', 'INFORMEI', 'INFORMAÇÃO',
  'CONTATAR', 'CONTATANDO', 'CONTATEI',
  'RESPONDER', 'RESPONDENDO', 'RESPONDI', 'RESPOSTA',
  'REDIGIR', 'REDIGINDO', 'REDIGI',
  'TRANSCREVER', 'TRANSCREVENDO', 'TRANSCREVI',
  'INSERIR', 'INSERINDO', 'INSERI',
  'LANÇAR', 'LANÇANDO', 'LANCEI',
  'ATUALIZAR', 'ATUALIZANDO', 'ATUALIZEI',
  'IMPLANTAR', 'IMPLANTANDO', 'IMPLANTEI',
  'REPARAR', 'REPARANDO', 'REPAREI', 'REPARO',
  'CONSERTAR', 'CONSERTANDO', 'CONSERTEI', 'CONSERTO',
  'SUBSTITUIR', 'SUBSTITUINDO', 'SUBSTITUÍ',
  'MOVIMENTAR', 'MOVIMENTANDO', 'MOVIMENTEI',
  'TRANSPORTAR', 'TRANSPORTANDO', 'TRANSPORTEI',
  'DESLOCAR', 'DESLOCANDO', 'DESLOQUEI',
  'PROVIDENCIAR', 'PROVIDENCIANDO', 'PROVIDENCIEI',
  'CHECAR', 'CHECANDO', 'CHEQUEI',
  'ANOTAR', 'ANOTANDO', 'ANOTEI', 'ANOTAÇÃO',
  'REGISTRAR', 'REGISTRANDO', 'REGISTREI',
  'LEITURA', 'LER', 'LENDO', 'LI',
  'ESTUDAR', 'ESTUDANDO', 'ESTUDEI', 'ESTUDO',

  // ── SECRETARIA / ADMINISTRATIVA ──────────────────────────────────────────────
  'SECRETARIA',
  'ADMINISTRATIVO', 'ADMINISTRATIVA',
  'GERÊNCIA', 'GERENCIAR', 'GERENCIANDO',
  'COORDENAÇÃO', 'COORDENAR', 'COORDENANDO',

  // ── LOCAIS / SETORES ────────────────────────────────────────────────────────
  'SETOR', 'SETORES',
  'SALA', 'SALAS',
  'ÁREA', 'ÁREAS',
  'COPA', 'COZINHA',
  'CORREDOR', 'CORREDORES',
  'BANHEIRO', 'BANHEIROS',
  'ALMOXARIFADO',
  'RECEPÇÃO',
  'ESCRITÓRIO',
  'ESTACIONAMENTO',
  'DEPÓSITO',

  // ── TEMPO / TURNO ────────────────────────────────────────────────────────────
  'MANHÃ', 'TARDE', 'NOITE',
  'DIA', 'DIAS',
  'SEMANA', 'SEMANAS',
  'MÊS', 'MESES',
  'TURNO', 'TURNOS',
  'PERÍODO', 'PERÍODOS',

  // ── ARTIGOS / PREPOSIÇÕES / CONJUNÇÕES (passam sem correção) ─────────────────
  'E', 'O', 'A', 'OS', 'AS',
  'DE', 'DO', 'DA', 'DOS', 'DAS',
  'EM', 'NO', 'NA', 'NOS', 'NAS',
  'COM', 'PARA', 'POR', 'AO', 'AOS',
  'UM', 'UMA', 'UNS', 'UMAS',
  'SE', 'QUE', 'NÃO', 'SIM',
  'FOI', 'FUI', 'ERA', 'FORAM', 'SER', 'ESTAR', 'TEM', 'TINHA',
  'MEU', 'MINHA', 'MEUS', 'MINHAS',
  'SEU', 'SUA', 'SEUS', 'SUAS',
  'ESTE', 'ESTA', 'ESTES', 'ESTAS',
  'ESSE', 'ESSA', 'ESSES', 'ESSAS',
  'AQUELE', 'AQUELA', 'AQUELES', 'AQUELAS',
  'MAIS', 'MENOS', 'MUITO', 'POUCO',
  'TODO', 'TODA', 'TODOS', 'TODAS',
  'OUTRO', 'OUTRA', 'OUTROS', 'OUTRAS',
  'NOVO', 'NOVA', 'NOVOS', 'NOVAS',
  'LOCAL', 'MESA',
]

// Distância de Levenshtein (edição mínima entre duas strings)
function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length
  const dp: number[][] = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => i === 0 ? j : j === 0 ? i : 0)
  )
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = a[i-1] === b[j-1]
        ? dp[i-1][j-1]
        : 1 + Math.min(dp[i-1][j], dp[i][j-1], dp[i-1][j-1])
  return dp[m][n]
}

const VOCAB_SET = new Set(VOCABULARIO)

// Corrige uma única palavra por correspondência aproximada
function corrigirPalavra(palavra: string): string {
  if (palavra.length <= 2) return palavra          // artigos/preposições: não mexe
  if (VOCAB_SET.has(palavra)) return palavra       // já está correta

  // Limite de diferença proporcional ao tamanho da palavra
  const limite = palavra.length <= 5 ? 1 : palavra.length <= 8 ? 2 : 3

  let melhor = palavra
  let menorDist = Infinity

  for (const ref of VOCABULARIO) {
    // Poda rápida por diferença de tamanho
    if (Math.abs(ref.length - palavra.length) > limite) continue
    const d = levenshtein(palavra, ref)
    if (d < menorDist) { menorDist = d; melhor = ref }
    if (d === 0) break // perfeito
  }

  return menorDist <= limite ? melhor : palavra
}

// Remove acentos para normalizar antes de comparar no split, mas preserva acentuação final
function corrigirOrtografia(texto: string): string {
  const upper = texto.toUpperCase()
  // Split preservando separadores (espaços, pontuação)
  return upper.split(/(\s+|[^A-ZÁÉÍÓÚÂÊÎÔÛÃÕÀÈÌÒÙÇ]+)/).map(token => {
    if (/^[A-ZÁÉÍÓÚÂÊÎÔÛÃÕÀÈÌÒÙÇ]+$/.test(token)) return corrigirPalavra(token)
    return token
  }).join('')
}

const schemaPost = z.object({
  recordId:    z.string().uuid(),
  description: z.string().trim().min(3, 'Descreva ao menos 3 caracteres').max(1000),
})

const schemaPatch = z.object({
  activityId:  z.string().uuid(),
  description: z.string().trim().min(3, 'Descreva ao menos 3 caracteres').max(1000),
})

const schemaDelete = z.object({
  activityId: z.string().uuid(),
})

function normalizar(texto: string): string {
  return corrigirOrtografia(texto.trim())
}

async function getInternId(user: { id: string }, db: ReturnType<typeof createSupabaseServiceClient>) {
  return user.id
}

export async function POST(req: NextRequest) {
  const supabase = await createSupabaseServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const parsed = schemaPost.safeParse(await req.json())
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 })
  }

  const { recordId, description } = parsed.data
  const db = createSupabaseServiceClient()

  const { data: record, error: recErr } = await db
    .from('time_records')
    .select('id, clock_out, intern_id')
    .eq('id', recordId)
    .eq('intern_id', user.id)
    .maybeSingle()

  if (recErr || !record) {
    return NextResponse.json({ error: 'Registro não encontrado' }, { status: 404 })
  }

  if (!record.clock_out) {
    return NextResponse.json({ error: 'Só é possível adicionar atividade após registrar a saída' }, { status: 400 })
  }

  const { data: activity, error } = await db
    .from('activities')
    .insert({ time_record_id: recordId, description: normalizar(description) })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Concede +5 pontos ao aluno
  const { data: profile } = await db.from('profiles').select('points').eq('id', user.id).maybeSingle()
  if (profile) {
    await db.from('profiles').update({ points: (profile.points ?? 0) + PONTOS_POR_ATIVIDADE }).eq('id', user.id)
  }

  return NextResponse.json({ activity })
}

export async function PATCH(req: NextRequest) {
  const supabase = await createSupabaseServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const parsed = schemaPatch.safeParse(await req.json())
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 })
  }

  const { activityId, description } = parsed.data
  const db = createSupabaseServiceClient()

  const { data: existing, error: findErr } = await db
    .from('activities')
    .select('id, time_record_id, time_records!inner(intern_id)')
    .eq('id', activityId)
    .maybeSingle()

  if (findErr || !existing) {
    return NextResponse.json({ error: 'Atividade não encontrada' }, { status: 404 })
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  if ((existing.time_records as any)?.intern_id !== user.id) {
    return NextResponse.json({ error: 'Sem permissão' }, { status: 403 })
  }

  const { data: activity, error } = await db
    .from('activities')
    .update({ description: normalizar(description) })
    .eq('id', activityId)
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  return NextResponse.json({ activity })
}

export async function DELETE(req: NextRequest) {
  const supabase = await createSupabaseServerClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Não autenticado' }, { status: 401 })

  const parsed = schemaDelete.safeParse(await req.json())
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 })
  }

  const { activityId } = parsed.data
  const db = createSupabaseServiceClient()

  const { data: existing, error: findErr } = await db
    .from('activities')
    .select('id, time_record_id, time_records!inner(intern_id)')
    .eq('id', activityId)
    .maybeSingle()

  if (findErr || !existing) {
    return NextResponse.json({ error: 'Atividade não encontrada' }, { status: 404 })
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  if ((existing.time_records as any)?.intern_id !== user.id) {
    return NextResponse.json({ error: 'Sem permissão' }, { status: 403 })
  }

  const { error } = await db.from('activities').delete().eq('id', activityId)
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Deduz -5 pontos ao excluir
  const { data: profile } = await db.from('profiles').select('points').eq('id', user.id).maybeSingle()
  if (profile) {
    await db.from('profiles').update({ points: Math.max(0, (profile.points ?? 0) - PONTOS_POR_ATIVIDADE) }).eq('id', user.id)
  }

  return NextResponse.json({ ok: true, pontosDebitados: PONTOS_POR_ATIVIDADE })
}
